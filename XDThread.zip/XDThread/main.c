/**************************************************
NOTA: Per compilar en codeblocks s'ha de'afegir la
opció de threads al compilador:
-Botó secundari a sobre del projecte
-Triar build Options
-Anar a la pestanya de Linker Settings
-Afegir amb el botó Add pthread (posar la paraula)
-Acceptar
****************************************************/
#include <pthread.h>
#include <stdio.h>
#define NUM_THREADS     5

/****************************************************
Funció que executen els Threads, treu un missatge per
pantalla, rep per paràmetre l'identificador del thread
*****************************************************/
void *printHola(void *threadid)
{
   long tid;
   tid = (long)threadid;
   printf("Hola! id thread #%ld!\n", tid);
   pthread_exit(NULL);
}

/*****************************************************
Funció principal que crea NUM_THREADS
******************************************************/
int main (int argc, char *argv[])
{
   pthread_t threads[NUM_THREADS]; //vector per guardar els identificadors dels threads
   int rc;
   long t;

   for(t=0; t<NUM_THREADS; t++){  // fa NUM_THREADS iteracions
      printf("Programa principal: creant thread %ld\n", t);
      rc = pthread_create(&threads[t], NULL, printHola, (void *)t);  //crea el Thread, envia la variable t per paràmetre

      if (rc){  //si hi ha hagut error creant el thread
         printf("ERROR; el codi d'error de pthread_create() és %d\n", rc);
         exit(-1);
      }
   }
   pthread_exit(NULL);
}
